import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import WelcomeScreen from './screens/WelcomeScreen';
import LetterGridScreen from './screens/LetterGridScreen';
import LetterScreen from './screens/LetterScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="LetterGrid" component={LetterGridScreen} />
        <Stack.Screen name="LetterScreen" component={LetterScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}