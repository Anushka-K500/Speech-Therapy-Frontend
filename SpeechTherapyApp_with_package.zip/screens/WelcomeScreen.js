import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';

export default function WelcomeScreen({ navigation }) {
  return (
    <ImageBackground source={require('../assets/bg.png')} style={styles.container}>
      <Text style={styles.title}>Speech{'
'}Therapy{'
'}App</Text>
      <TouchableOpacity style={styles.loginButton} onPress={() => navigation.navigate('LetterGrid')}>
        <Text style={styles.loginText}>login</Text>
      </TouchableOpacity>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: {
    fontSize: 36,
    textAlign: 'center',
    color: '#D22B2B',
    fontFamily: 'Cochin',
    marginBottom: 20,
  },
  loginButton: {
    backgroundColor: '#B9FBC0',
    paddingVertical: 10,
    paddingHorizontal: 40,
    borderRadius: 20,
  },
  loginText: { color: '#000', fontSize: 18 },
});