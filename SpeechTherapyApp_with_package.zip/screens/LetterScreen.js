import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function LetterScreen({ route, navigation }) {
  const { letter } = route.params;

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
        <Ionicons name="arrow-back" size={28} color="#000" />
      </TouchableOpacity>
      <View style={styles.letterBox}>
        <Text style={styles.letter}>{letter}</Text>
      </View>
      <TouchableOpacity style={styles.micButton}>
        <Ionicons name="mic" size={36} color="#fff" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#E3F2FD', justifyContent: 'center', alignItems: 'center' },
  back: { position: 'absolute', top: 40, left: 20 },
  letterBox: {
    width: 150,
    height: 150,
    backgroundColor: '#2196F3',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  letter: { fontSize: 64, color: '#fff' },
  micButton: {
    backgroundColor: '#263238',
    padding: 20,
    borderRadius: 50,
    marginTop: 40,
  },
});